﻿using System;
using System.Collections.Generic;


namespace phone_book_app
{
    class Program
    {
        public static void Menu()
            {
                Console.WriteLine("==================================");
                Console.WriteLine("\nMostrar todos contatos - 1");
                Console.WriteLine("Procurar um contato - 2");
                Console.WriteLine("Ordenar por nome - 3");
                Console.WriteLine("Ordenar por email - 4");
                Console.WriteLine("Adicionar contato - 5");
                Console.WriteLine("Para atualizar contato - 6");
                Console.WriteLine("Deletar contato - 7");
                Console.WriteLine("Salvar contatos - 8");
                Console.WriteLine("Sair - 0");
                Console.WriteLine("==================================");
            }

        static void Main(string[] args)
        {
            var listaTelef = new LinkedList<Contato>();
            var agenda = new Agenda(listaTelef);
            String nome, email, celular;
            int choice, ident = 0;

            do
            {
                Menu();

                Console.Write("\nQual deseja fazer? ");
                choice = Convert.ToInt32(Console.ReadLine());

                switch(choice)
                {
                    case 0:
                        Console.WriteLine("Saindo");
                        System.Environment.Exit(0);
                        break;
                    case 1:
                        agenda.ListarTodos();
                        break;
                    case 2:
                        Console.Write("Digite o ID do contato: ");
                        int idenficacao = Convert.ToInt32(Console.ReadLine());
                        agenda.ListarContatoUnico(idenficacao);
                        break;
                    case 3:
                        agenda.OrdenandoPorNome();
                        break;
                    case 4:
                        agenda.OrdenandoPorEmail();
                        break;
                    case 5:
                        Console.Write("Digite o nome do contato: ");
                        nome = Console.ReadLine();
                        Console.Write("Digite o email do contato: ");
                        email = Console.ReadLine();
                        Console.Write("Digite o celular do contato: ");
                        celular = Console.ReadLine();
                        agenda.Armazenar(new Contato(ident, nome, email, celular));
                        ident += 1;
                        break;
                    case 6:
                        Console.Write("Digite o ID do contato: ");
                        idenficacao = Convert.ToInt32(Console.ReadLine());

                        agenda.ApagarContato(idenficacao);
                        break;
                    case 7:
                        Console.Write("Digite o ID do contato: ");
                        idenficacao = Convert.ToInt32(Console.ReadLine());

                        Console.Write("Digite o nome do contato: ");
                        nome = Console.ReadLine();

                        Console.Write("Digite o email do contato: ");
                        email = Console.ReadLine();

                        Console.Write("Digite o celular do contato: ");
                        celular = Console.ReadLine();

                        agenda.Atualizar(idenficacao, nome, email, celular);
                        break;
                    case 8:
                        agenda.Salvar();
                        break;
                    default:
                        Console.WriteLine("Número errado");
                        break;
                }

            } while (true);
        }


    }
}
