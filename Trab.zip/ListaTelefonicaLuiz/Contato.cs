using System;
public class Contato {
    private int ident; private string nome; private string email; private string celular;

    public Contato(int ident) {
        this.ident = ident;
    }
    public Contato(int ident, string nome, string email, string celular) {
        this.ident = ident;
        this.nome = nome;
        this.email = email;
        this.celular = celular;
    }
    public override string ToString() {
       return $"Id: {ident} - name: {nome} - celular: {celular} - email: {email}";
    }
    public int Ident{
        get { return ident; } 
        set { ident = value; }
    }
    public string Nome{
        get { return nome; }   
        set { nome = value; } 
    }
    public string Celular{
        get { return celular; }   
        set { celular = value; } 
    }
    public string Email{
        get { return email; }   
        set { email = value; } 
    }
}
