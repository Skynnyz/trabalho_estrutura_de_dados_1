using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

public class Agenda {
    private LinkedList<Contato> listaTelef = new LinkedList<Contato>();
    public Agenda(LinkedList<Contato> listaTelef) {
        this.listaTelef = listaTelef;
    }
    public LinkedList<Contato> ListaTelef {
        get { return listaTelef; } 
        set { listaTelef = value; } 
    }
    public void ListarTodos() {
        foreach (var contato in listaTelef) {
            Console.WriteLine(contato.ToString());
        }
    }
    public void ListarContatoUnico(int identificacao) {
        foreach (var contato in listaTelef) {
            if (contato.Ident.Equals(identificacao)) {
                Console.WriteLine(contato.ToString());
            }
        }
    }
    public void Armazenar(Contato contato){
        //Adiciona novo contato ao fim da lista
        listaTelef.AddLast(contato);
    }

    public void OrdenandoPorNome(){
        using (var file = new StreamWriter("Agenda.txt")){
            var sorted = listaTelef
                .OrderBy(item => item.Nome)
                .ToList();

            Console.WriteLine("\n--| Ordenando: |--");
            foreach(var contato in sorted){
                Console.WriteLine(contato.ToString());
                file.WriteLine(contato.ToString());
            }
        }
    }
        public void OrdenandoPorEmail(){
        using (var file = new StreamWriter("Agenda.txt")){
            var sorted = listaTelef
                .OrderBy(item => item.Email)
                .ToList();
            Console.WriteLine("\n--| Ordenando: |--");
            foreach(var contato in sorted){
                Console.WriteLine(contato.ToString());
                file.WriteLine(contato.ToString());
            }
        }
    }

    public void Atualizar(int identificacao, String nome, String email, String celular){
        //Procura o contato que se enquadra no ID e atualiza os itens desejados
        foreach (var contato in listaTelef.Where(item => item.Ident.Equals(identificacao)).ToArray()){
            contato.Ident = identificacao;
            contato.Nome = nome;
            contato.Email = email;
            contato.Celular = celular;
        }
    }
    public void Salvar(){
        //Salva cada contato na agenda.txt
        using (var file = new StreamWriter("Agenda.txt")){
            foreach (var contato in listaTelef){
                file.WriteLine(contato.ToString());
            }
        }
        Console.WriteLine("\n--| Lista registrada |--\n");
    }

        public void ApagarContato(int identificacao){
        //Procura o contato que se enquadra no ID e apaga
        foreach (var contato in listaTelef.Where(item => item.Ident.Equals(identificacao)).ToArray()){
            listaTelef.Remove(contato);
        }
    }

}
